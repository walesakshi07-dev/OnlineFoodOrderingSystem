<?php
include 'includes/config.php';
include 'includes/header.php';

if(isset($_POST['submit']))
{
    $orderid = $_POST['orderid'];
    $method = $_POST['method'];
    $date = date("Y-m-d");
    $status = $_POST['status'];

    $query = "INSERT INTO Payments(OrderID, PaymentMethod, PaymentDate, PaymentStatus)
              VALUES('$orderid','$method','$date','$status')";
mysqli_query($conn,$query);

echo "<script>
alert('Payment Successful!');
window.location='success.php';
</script>";
exit();
    }
?>

<div class="container">

<h1>Payment</h1>

<form method="POST">

<label>Select Order</label><br><br>

<select name="orderid" required>

<?php
$result = mysqli_query($conn,"SELECT * FROM Orders");

while($row = mysqli_fetch_assoc($result))
{
?>

<option value="<?php echo $row['OrderID']; ?>">
Order <?php echo $row['OrderID']; ?>
</option>

<?php
}
?>

</select>

<br><br>

<label>Payment Method</label><br><br>

<label><b>Select Payment Method</b></label><br><br>

<input type="radio" name="method" value="UPI" required> UPI <br><br>

<input type="radio" name="method" value="Cash on Delivery"> Cash on Delivery <br><br>

<input type="radio" name="method" value="Credit/Debit Card"> Credit / Debit Card <br><br>
<br><br>

<label>Payment Status</label><br><br>


<select name="status">

<option value="Paid">Paid</option>

<option value="Pending">Pending</option>

</select>

<br><br>

<input type="submit" name="submit" value="Pay Now">

</form>

</div>

<?php
include 'includes/footer.php';
?>