<?php
include 'includes/config.php';
include 'includes/header.php';

$query = "SELECT
Payments.PaymentID,
Customers.CustomerName,
Payments.PaymentMethod,
Payments.PaymentDate,
Payments.PaymentStatus
FROM Payments
INNER JOIN Orders
ON Payments.OrderID = Orders.OrderID
INNER JOIN Customers
ON Orders.CustomerID = Customers.CustomerID";

$result = mysqli_query($conn,$query);
?>

<div class="container">

<h1>Payment Details</h1>

<table border="1" cellpadding="10" cellspacing="0">

<tr>
    <th>Payment ID</th>
    <th>Customer Name</th>
    <th>Payment Method</th>
    <th>Payment Date</th>
    <th>Payment Status</th>
</tr>

<?php
while($row = mysqli_fetch_assoc($result))
{
?>

<tr>
    <td><?php echo $row['PaymentID']; ?></td>
    <td><?php echo $row['CustomerName']; ?></td>
    <td><?php echo $row['PaymentMethod']; ?></td>
    <td><?php echo $row['PaymentDate']; ?></td>
    <td><?php echo $row['PaymentStatus']; ?></td>
</tr>

<?php
}
?>

</table>

</div>

<?php
include 'includes/footer.php';
?>