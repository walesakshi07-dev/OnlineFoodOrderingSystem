<?php
include 'includes/header.php';
?>

<div class="hero">

    <h1>🎉 Order Placed Successfully!</h1>

    <p>Your order has been placed successfully.</p>
    <p>Thank you for ordering with us!</p>

    <br>

    <a href="index.php">
        <button>Back to Home</button>
    </a>

    <a href="view_orders.php">
        <button>View Orders</button>
    </a>

</div>

<?php
include 'includes/footer.php';
?>