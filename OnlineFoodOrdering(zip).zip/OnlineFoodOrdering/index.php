<?php
include 'includes/config.php';
include 'includes/header.php';
?>

<section class="hero">

<h1>🍔 Welcome to Online Food Ordering System</h1>

<p>Order your favourite food quickly and easily.</p>

<a href="restaurants.php">
    <button>Order Now</button>
</a>

</section>

<?php
include 'includes/footer.php';
?>