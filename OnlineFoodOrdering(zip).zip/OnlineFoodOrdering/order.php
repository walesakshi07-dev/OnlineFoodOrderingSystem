<?php
include 'includes/config.php';
include 'includes/header.php';

if(isset($_POST['submit']))
{
$customername = $_POST['customername'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$address = $_POST['address'];

$foodid = $_POST['foodid'];
$quantity = $_POST['quantity'];

$date = date("Y-m-d");

$check = mysqli_query($conn,"SELECT * FROM Customers WHERE Email='$email'");

if(mysqli_num_rows($check) > 0)
{
    $row = mysqli_fetch_assoc($check);
    $customerid = $row['CustomerID'];
}
else
{
    mysqli_query($conn,"INSERT INTO Customers(CustomerName, Phone, Email, Password, Address)
    VALUES('$customername','$phone','$email','12345','$address')");

    $customerid = mysqli_insert_id($conn);
}
    // Food Price मिळवा
    $price_query = mysqli_query($conn,"SELECT Price FROM FoodItems WHERE FoodID='$foodid'");
    $price = mysqli_fetch_assoc($price_query);

    $total = $price['Price'] * $quantity;

    mysqli_query($conn,"INSERT INTO Orders(CustomerID,FoodID,Quantity,OrderDate,TotalAmount)
    VALUES('$customerid','$foodid','$quantity','$date','$total')");
echo "<script>
alert('Order Placed Successfully!');
window.location='payment.php';
</script>";

}
?>

<div class="container">

<h1>Place Your Order</h1>

<form method="POST">

<label>Customer Name</label><br><br>
<input type="text" name="customername" required>

<br><br>

<label>Phone</label><br><br>
<input type="text" name="phone" required>

<br><br>

<label>Email</label><br><br>
<input type="email" name="email" required>

<br><br>

<label>Address</label><br><br>
<input type="text" name="address" required>

<br><br>

<label>Select Food</label><br><br>

<select name="foodid">

<?php

$result=mysqli_query($conn,"SELECT * FROM FoodItems");

while($row=mysqli_fetch_assoc($result))
{
?>

<option value="<?php echo $row['FoodID']; ?>">
<?php echo $row['FoodName']; ?>
</option>

<?php } ?>

</select>

<br><br>

<label>Quantity</label><br><br>

<input type="number" name="quantity" required>

<br><br>

<input type="submit" name="submit" value="Place Order">

</form>

</div>

<?php
include 'includes/footer.php';
?>