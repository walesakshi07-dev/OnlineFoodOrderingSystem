<?php
include 'includes/config.php';
include 'includes/header.php';

$query = "SELECT
Customers.CustomerName,
FoodItems.FoodName,
Orders.Quantity,
Orders.TotalAmount,
Orders.OrderDate
FROM Orders
INNER JOIN Customers
ON Orders.CustomerID = Customers.CustomerID
INNER JOIN FoodItems
ON Orders.FoodID = FoodItems.FoodID";

$result = mysqli_query($conn, $query);
?>

<div class="container">

<h1>All Orders</h1>

<table border="1" cellpadding="10" cellspacing="0">

<tr>
    <th>Customer Name</th>
    <th>Food Name</th>
    <th>Quantity</th>
    <th>Total Amount</th>
    <th>Order Date</th>
</tr>

<?php
while($row = mysqli_fetch_assoc($result))
{
?>

<tr>
    <td><?php echo $row['CustomerName']; ?></td>
    <td><?php echo $row['FoodName']; ?></td>
    <td><?php echo $row['Quantity']; ?></td>
    <td>₹<?php echo $row['TotalAmount']; ?></td>
    <td><?php echo $row['OrderDate']; ?></td>
</tr>

<?php
}
?>

</table>

</div>

<?php
include 'includes/footer.php';
?>