<?php
include '../includes/config.php';

$totalCustomers = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM Customers"));
$totalRestaurants = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM Restaurants"));
$totalFoodItems = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM FoodItems"));
$totalOrders = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM Orders"));
$totalPayments = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM Payments"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>

    <style>

    body{
        font-family:Arial;
        background:#f4f4f4;
        text-align:center;
    }

    h1{
        margin-top:30px;
        color:#ff5722;
    }

    .box{
        width:220px;
        height:150px;
        background:white;
        display:inline-block;
        margin:20px;
        padding:20px;
        border-radius:10px;
        box-shadow:0px 0px 10px gray;
    }

    .box h2{
        color:#ff5722;
    }

    .box p{
        font-size:30px;
        font-weight:bold;
    }

    </style>

</head>

<body>

<h1>🍔 Online Food Ordering System</h1>

<div class="box">
    <h2>Customers</h2>
    <p><?php echo $totalCustomers; ?></p>
</div>

<div class="box">
    <h2>Restaurants</h2>
    <p><?php echo $totalRestaurants; ?></p>
</div>

<div class="box">
    <h2>Food Items</h2>
    <p><?php echo $totalFoodItems; ?></p>
</div>

<div class="box">
    <h2>Orders</h2>
    <p><?php echo $totalOrders; ?></p>
</div>

<div class="box">
    <h2>Payments</h2>
    <p><?php echo $totalPayments; ?></p>
</div>

</body>
</html>
<hr><br>

<h2>Quick Links</h2>

<p><a href="../index.php">🏠 Home</a></p>

<p><a href="../view_customers.php">👥 View Customers</a></p>

<p><a href="../view_fooditems.php">🍕 View Food Items</a></p>

<p><a href="../view_orders.php">🛒 View Orders</a></p>

<p><a href="../view_payments.php">💳 View Payments</a></p>