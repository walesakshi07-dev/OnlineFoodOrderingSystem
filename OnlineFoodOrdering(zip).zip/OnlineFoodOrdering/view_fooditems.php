<?php
include 'includes/config.php';
include 'includes/header.php';

$query = "SELECT FoodItems.FoodID,
                 FoodItems.FoodName,
                 FoodItems.Price,
                 Restaurants.RestaurantName
          FROM FoodItems
          INNER JOIN Restaurants
          ON FoodItems.RestaurantID = Restaurants.RestaurantID";

$result = mysqli_query($conn, $query);
?>

<div class="container">

<h1>Food Items</h1>

<table border="1" cellpadding="10" cellspacing="0">

<tr>
    <th>Food ID</th>
    <th>Food Name</th>
    <th>Restaurant</th>
    <th>Price</th>
</tr>

<?php
while($row = mysqli_fetch_assoc($result))
{
?>

<tr>
    <td><?php echo $row['FoodID']; ?></td>
    <td><?php echo $row['FoodName']; ?></td>
    <td><?php echo $row['RestaurantName']; ?></td>
    <td>₹<?php echo $row['Price']; ?></td>
</tr>

<?php
}
?>

</table>

</div>

<?php
include 'includes/footer.php';
?>