<?php
include 'includes/config.php';
include 'includes/header.php';

$query = "SELECT * FROM Restaurants";
$result = mysqli_query($conn, $query);
?>

<div class="container">

    <h1>Our Restaurants</h1>

    <?php while($row = mysqli_fetch_assoc($result)) { ?>

        <div class="card">

            <h2><?php echo $row['RestaurantName']; ?></h2>

            <p>📍 <?php echo $row['Location']; ?></p>

            <a href="menu.php">
                <button>View Menu</button>
            </a>

        </div>

    <?php } ?>

</div>

<?php
include 'includes/footer.php';
?>
<div class="card">

<img src="images/pizza.jpg" width="220" height="150">

<h2>Pizza Hut</h2>

<p>Location : Pune</p>

<a href="menu.php">
<button>View Menu</button>
</a>

</div>