<?php
include 'includes/config.php';
include 'includes/header.php';

$query = "SELECT FoodItems.*, Restaurants.RestaurantName
          FROM FoodItems
          INNER JOIN Restaurants
          ON FoodItems.RestaurantID = Restaurants.RestaurantID";

$result = mysqli_query($conn, $query);
?>

<div class="container">

    <h1>Food Menu</h1>

    <?php while($row = mysqli_fetch_assoc($result)) { ?>

        <div class="card">

            <h2><?php echo $row['FoodName']; ?></h2>

            <p><strong>Restaurant:</strong> <?php echo $row['RestaurantName']; ?></p>

            <p><strong>Price:</strong> ₹<?php echo $row['Price']; ?></p>

            <a href="order.php?foodid=<?php echo $row['FoodID']; ?>">
                <button>Order Now</button>
            </a>

        </div>

    <?php } ?>

</div>

<?php
include 'includes/footer.php';
?>