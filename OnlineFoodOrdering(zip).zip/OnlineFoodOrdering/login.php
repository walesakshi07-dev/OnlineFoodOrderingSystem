<?php
session_start();

if(isset($_POST['login']))
{
    $username = $_POST['username'];
    $password = $_POST['password'];

    if($username=="admin" && $password=="admin123")
    {
        $_SESSION['admin']=$username;
        header("Location: admin/dashboard.php");
        exit();
    }
    else
    {
        $error = "Invalid Username or Password!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="login-body">

<div class="login-box">

<h1>🍔 Food Ordering</h1>
<h3>Admin Login</h3>

<?php
if(isset($error))
{
    echo "<p class='error'>$error</p>";
}
?>

<form method="POST">

<input type="text" name="username" placeholder="Enter Username" required>

<input type="password" name="password" placeholder="Enter Password" required>

<input type="submit" name="login" value="Login">

</form>

</div>

</body>
</html>