<?php
include 'includes/config.php';
include 'includes/header.php';

$query = "SELECT * FROM Customers";
$result = mysqli_query($conn, $query);
?>

<div class="container">

<h1>Customer Details

<?php
include 'includes/config.php';
include 'includes/header.php';

$query = "SELECT * FROM Customers";
$result = mysqli_query($conn, $query);
?>

<div class="container">

<h1>Customer Details</h1>

<table border="1" cellpadding="10" cellspacing="0">

<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Phone</th>
    <th>Email</th>
    <th>Address</th>
</tr>

<?php
while($row = mysqli_fetch_assoc($result))
{
?>

<tr>
    <td><?php echo $row['CustomerID']; ?></td>
    <td><?php echo $row['CustomerName']; ?></td>
    <td><?php echo $row['Phone']; ?></td>
    <td><?php echo $row['Email']; ?></td>
    <td><?php echo $row['Address']; ?></td>
</tr>

<?php
}
?>

</table>

</div>

<?php
include 'includes/footer.php';
?>