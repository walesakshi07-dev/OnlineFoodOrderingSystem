<?php

$conn = mysqli_connect("localhost","root","sakshi2005","online_food_ordering");

if(!$conn)
{
    die("Connection Failed : ".mysqli_connect_error());
}

?>