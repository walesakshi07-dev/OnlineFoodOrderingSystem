<footer>
    <p>&copy; 2026 Online Food Ordering System | Developed by Sakshi</p>
</footer>

</body>
</html>
<footer>
    <p>&copy; 2026 Online Food Ordering System | Developed by Sakshi Wale</p>
</footer>

</body>
</html>