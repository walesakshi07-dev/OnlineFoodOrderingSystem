<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Food Ordering System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>

<h2>🍔 Online Food Ordering System</h2>

<nav>
    <a href="index.php">Home</a>
    <a href="restaurants.php">Restaurants</a>
    <a href="menu.php">Menu</a>
    <a href="order.php">Order</a>
    <a href="payment.php">Payment</a>
    <a href="view_orders.php">Orders</a>
    <a href="view_customers.php">Customers</a>
    <a href="view_fooditems.php">Food Items</a>
    <a href="view_payments.php">Payments</a>
</nav>

</header>
<img src="images/logo.png" width="60">

<h2>Online Food Ordering System</h2>